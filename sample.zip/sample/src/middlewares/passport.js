const passport = require('passport');
const passportJWT = require('passport-jwt');
const LocalStrategy = require('passport-local').Strategy;
const repo = require('../repository/account-repository');
const JWTStrategy = passportJWT.Strategy;
const ExtractJWT = passportJWT.ExtractJwt;
const { PASSPORT } = require('../config');

module.exports.initialize = () => {

    passport.use(new LocalStrategy({
        usernameField: 'email',
        passwordField: 'password'
    },
        async function (email, password, callback) {
            try {
                let user = await repo.getUserByEmailAndPassword(email, password);
                if (user) {
                    callback(null, user, {
                        message: 'User logged in successfully!'
                    });
                } else {
                    callback(null, false, { message: 'Incorrect email or password.' });
                }
            } catch (err) {
                callback(err);
            }
        }
    ));

    passport.use(new JWTStrategy({
        jwtFromRequest: ExtractJWT.fromAuthHeaderAsBearerToken(),
        secretOrKey: PASSPORT.SECRET
    },
        async function (jwtPayload, callback) {
            try {
                let user = await repo.getUserById(jwtPayload._id);
                callback(null, user);
            } catch (err) {
                callback(err);
            }
        }
    ));
};