module.exports = {
    PASSPORT : {
        SECRET : 'ZeVRHhCwJG95k7L2feMm'
    },
    MONGO:{
        HOST:'127.0.0.1',
        PORT:'27017',
        USERNAME:'',
        PASSWORD:'',
        DBNAME:'pentaur'
    }
};