const fs = require('fs');
const path = require('path');
let config = require('../config/config-local');

if (process.env.NODE_ENV !== 'local') {
    let configPath = path.join(__dirname,`config-${process.env.NODE_ENV}`);
    if(fs.existsSync(configPath)){
        config = require(configPath);
    }
}

module.exports = config;