const mongoose = require('mongoose');
const { MONGO } = require('../config');

const getConnectionString = ()=>{
    let url = 'mongodb://'
    if(MONGO.USERNAME && MONGO.PASSWORD){
        url += `${MONGO.USERNAME}:${MONGO.PASSWORD}@`;
    }
    url += `${MONGO.HOST}:${MONGO.PORT}/${MONGO.DBNAME}`;
    return url;
};

exports.initialize = () => {
    mongoose.connect(getConnectionString(),{
        useNewUrlParser : true
    });

    mongoose.connection.on('connected', () => {
        console.log(`Db connected`);
    });

    mongoose.connection.on('disconnected', () => {
        console.log(`Db disconnected`);
    });
};