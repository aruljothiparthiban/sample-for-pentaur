const repo = require('../repository/account-repository');

module.exports.me = async (req, res) => {
    try{    
        let user = await repo.getUserById(req.user._id);
        res.send(user);
    }catch(err){
        res.status(500).send(err);
    } 
};