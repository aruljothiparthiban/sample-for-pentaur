const repo = require('../repository/commodity-repository');
const priceDetailRepo = require('../repository/price-detail-repository');

module.exports.get = async (req, res) => {
    try {
        let commodity = await repo.get(req.params.id);
        if (commodity === null) {
            res.status(404).send('Commodity not found!');
        } else {
            commodity.currentPrice = await priceDetailRepo.getByCommodityId(commodity.commodityId);
            res.send(commodity);
        }
    } catch (err) {
        res.status(500).send(err);
    }
};

module.exports.create = async (req, res) => {
    try {
        let model = req.body;
        model.createdBy = model.updatedBy = req.user._id;
        let id = await repo.create(req.body);
        res.setHeader('location', req.baseUrl + '/' + id);
        res.status(201).send({
            message : 'Commodity created successfully!'
        });
    } catch (err) {
        res.status(500).send(err);
    }
};

module.exports.update = async (req, res) => {
    try {
        let model = req.body;
        model.updatedBy = req.user._id;
        let isUpdated = await repo.update(req.params.id, model);
        if (isUpdated) {
            res.status(204).end();
        } else {
            res.status(404).send('Commodity not found!');
        }
    } catch (err) {
        res.status(500).send(err);
    }
};