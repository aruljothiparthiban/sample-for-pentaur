const repo = require('../repository/account-repository');
const jwt = require('jsonwebtoken');
const passport = require('passport');
const { PASSPORT } = require('../config');

module.exports.signin = (req, res, next) => {
    passport.authenticate('local', { session: false }, (err, user, info) => {
        if (err || !user) {
            res.status(500).json({
                message: 'Incorrect email or password.'
            });
        }
        req.login(user, { session: false }, (err) => {
            if (err) {
                res.send(err);
            }
            const token = jwt.sign(user, PASSPORT.SECRET);
            res.json({ 
                user, 
                token 
            });
        });
    })(req, res);
};

module.exports.signup = async (req,res)=>{

    let model = req.body;
    try{    
        let user = await repo.createUser(model);
        res.send(user);
    }catch(err){
        res.status(500).send(err);
    }    
};