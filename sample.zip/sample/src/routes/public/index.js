var accountRouter = require('./account-routes');

module.exports.init = (app) => {
    app.use('/api/account', accountRouter);
};