const passport = require('passport');
const userRouter = require('./user-routes');
const commodityRouter = require('./commodity-routes');
const priceDetailRouter = require('./price-detail-routes');

module.exports.init = (app) => {
    app.use(passport.authenticate('jwt', {session: false}));
    
    app.use('/api/user', userRouter);
    app.use('/api/commodity', commodityRouter);
    app.use('/api/price-detail', priceDetailRouter);
};