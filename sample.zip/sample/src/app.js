process.env.NODE_ENV = process.env.NODE_ENV || 'test';

var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();

var publicRouter = require('./routes/public');
var protectedRouter = require('./routes/protected');

var mongoHelper = require('./helpers/mongo');
var passportMiddleware = require('./middlewares/passport');

mongoHelper.initialize();
passportMiddleware.initialize();
app.use(bodyParser.json());

protectedRouter.init(app);
publicRouter.init(app);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

var port = process.env.PORT || 5000;
app.listen(port, ()=>{
    console.log(`Server is listening on the port ${port}`);
});