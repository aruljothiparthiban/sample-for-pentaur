const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const CommoditySchema = new Schema({
    commodityId: {
        type: String,
        required: [true, 'Commodity id is required'],
        unique: true
    },
    name: {
        type: String,
        require: [true, 'Commodity name is required']
    },
    description: {
        type: String,
        required: [true, 'Commodity description is required']
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
    createdBy: {
        type: ObjectId,
        ref: 'User'
    },
    updatedBy: {
        type: ObjectId,
        ref: 'User'
    }
});

CommoditySchema.index({ commodityId: 1 });

module.exports = mongoose.model('Commodity', CommoditySchema);
