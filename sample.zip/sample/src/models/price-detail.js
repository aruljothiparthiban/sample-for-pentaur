const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const PriceDetailSchema = new Schema({
    commodityId: {
        type: String,
        required: [true, 'Commodity id is required'],
        unique: true
    },
    price: {
        type: Number,
        require: [true, 'Price is required']
    },
    currency: {
        type: String,
        required: [true, 'Currency is required']
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
    createdBy: {
        type: ObjectId,
        ref: 'User'
    },
    updatedBy: {
        type: ObjectId,
        ref: 'User'
    }
});

PriceDetailSchema.index({ commodityId: 1 });

module.exports = mongoose.model('PriceDetail', PriceDetailSchema);
