const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const UserSchema = new Schema({
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true
    },
    password: {
        type:String,
        require:[true, 'Password is required']
    },
    userName: {
        type: String,
        required: [true, 'User Name is required'],
        unique: true
    },
    firstName: {
        type: String,
        required: [true, 'First Name is required']
    },
    lastName: {
        type: String,
        required: [ true,'Last Name is required']
    },
    gender: {
        type: String,
        required: [true, 'Gender is required']
    },
    country: {
        type: String,
        required: [true, 'Country is required']
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

UserSchema.index({ email: 1, userName: 1 });

module.exports = mongoose.model('User', UserSchema);
