const Commodity = require('../models/commodity');
const PriceDetail = require('../models/price-detail');

module.exports.get = (commodityId) => {
    return new Promise((resolve, reject) => {
        Commodity.findOne({
            commodityId
        }, {
                _id : 0,
                commodityId: 1,
                name: 1,
                description: 1
            }).lean().exec((err, commodity) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(commodity);
                }
            });
    });
};

module.exports.create = (model) => {
    let commodity = new Commodity(model);
    return new Promise((resolve, reject) => {
        commodity.save((err) => {
            if (err) {
                reject(err);
            } else {
                resolve(commodity.commodityId);
            }
        });
    }).then(commodityId=>{
        if(model.currentPrice){
            return new Promise((resolve, reject)=>{
                let { price, currency } = model.currentPrice;
                let currentPrice = new PriceDetail({
                    price,
                    currency,
                    commodityId
                });
                currentPrice.save((err) => {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(commodityId);
                    }
                });
            });
        }else{
            return Promise.resolve(commodityId);
        }
    });
};

module.exports.update = (commodityId, model) => {
    let { name, description, updatedBy } = model;
    return new Promise((resolve, reject) => {
        Commodity.update({ commodityId }, {
            $set: { name, description, updatedBy }
        }, (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result.n>0);
            }
        });
    }).then(isUpdated=>{
        if(model.currentPrice){
            return new Promise((resolve, reject)=>{
                let { price, currency } = model.currentPrice;
                PriceDetail.update({ commodityId }, {
                    $set: { price, currency, updatedBy }
                },  { upsert : true } , (err, result) => {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(result.n>0);
                    }
                });
            });
        }else{
            return Promise.resolve(isUpdated);
        }
    });
};