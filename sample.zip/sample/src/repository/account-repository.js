const User = require('../models/user');

const getUserByQuery = (query)=>{
    return new Promise((resolve, reject) => {
        User.findOne(query, {
            email: 1,
            firstName: 1,
            lastName: 1,
            userName: 1,
            gender: 1,
            country: 1
        }).lean().exec((err, user) => {
            if (err) {
                reject(err);
            } else {
                resolve(user);
            }
        });
    });
};

module.exports.getUserByEmail = (email) => {
    return getUserByQuery({ email });
};

module.exports.getUserById = (_id)=>{
    return getUserByQuery({ _id });
};

module.exports.getUserByEmailAndPassword = (email, password)=>{
    return getUserByQuery({ email, password });
};

module.exports.createUser = (model) => {
    let user = new User(model);
    return new Promise((resolve, reject) => {
        user.save((err) => {
            if (err) {
                reject(err);
            } else {
                let model = {
                    _id : user._id,
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    userName: user.userName,
                    gender: user.gender,
                    country: user.country
                }
                resolve(model);
            }
        })
    });
};