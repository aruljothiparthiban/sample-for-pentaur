const PriceDetail = require('../models/price-detail');

const findPriceDetail = (query, projections)=>{
    return new Promise((resolve, reject) => {
        PriceDetail.findOne(query, projections).lean().exec((err, priceDetail) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(priceDetail);
                }
            });
    });
};

module.exports.get = (_id) => {
    return findPriceDetail({ _id }, {
        commodityId: 1,
        price: 1,
        currency: 1
    });
};

module.exports.getByCommodityId = (commodityId) => {
    return findPriceDetail({ commodityId }, {
        _id : 0,
        price: 1,
        currency: 1
    });
};

module.exports.create = (model) => {
    let priceDetail = new PriceDetail(model);
    return new Promise((resolve, reject) => {
        priceDetail.save((err) => {
            if (err) {
                reject(err);
            } else {
                resolve(priceDetail._id);
            }
        });
    });
};

module.exports.update = (_id, model) => {
    let { price, currency, updatedBy } = model;
    return new Promise((resolve, reject) => {
        PriceDetail.update({ _id }, {
            $set: { price, currency, updatedBy }
        }, (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result.n>0);
            }
        });
    });
};